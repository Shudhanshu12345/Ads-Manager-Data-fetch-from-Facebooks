from flask import Flask, render_template
import requests

app = Flask(__name__)

def get_facebook_data(access_token):
    url = f"https://graph.facebook.com/v19.0/act_577400774470979/insights"
    response = requests.get(url)
    data = response.json()
    return data

@app.route('/')
def index():
    access_token = 'EAAKhTWpPcP8BO2FI7KYN4xLrjHukN56Bh07LZC6Bt0egxXEBMwoyTRpkzYaakwSziZBzCy4ieAej0S0tgu2tKHA1mDguQaauR9cwIrSz0itaKM5gXipNaxEJ3kkeHVPZBHbL5oR0FAgZC9aPE9AOTNKZCPMe1eRZBNRZAbEpZCnYGPxqGyzMimULlZAUuZC9ZC0o77qUCVyC6e1ks4qaENPZAAZDZDsss'
    facebook_data = get_facebook_data(access_token)
    campaign_insights = facebook_data.get('data', [])

    return render_template('index.html', campaign_insights=campaign_insights)

if __name__ == '__main__':
    app.run(debug=True)
